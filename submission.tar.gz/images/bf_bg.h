/*
 * Exported with nin10kit v1.8
 * Time-stamp: Friday 11/16/2018, 16:07:49
 * 
 * Image Information
 * -----------------
 * /home/leaf/Dropbox/courses/2110/assignments/10/img_res/bf_bg.png 333@259
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BF_BG_H
#define BF_BG_H

extern const unsigned short bf_bg[86247];
#define BF_BG_SIZE 172494
#define BF_BG_LENGTH 86247
#define BF_BG_WIDTH 333
#define BF_BG_HEIGHT 259

#endif

