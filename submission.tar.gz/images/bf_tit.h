/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 bf_tit ../img_res/bf_tit.jpg 
 * Time-stamp: Monday 11/19/2018, 12:48:40
 * 
 * Image Information
 * -----------------
 * ../img_res/bf_tit.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BF_TIT_H
#define BF_TIT_H

extern const unsigned short bf_tit[38400];
#define BF_TIT_SIZE 76800
#define BF_TIT_LENGTH 38400
#define BF_TIT_WIDTH 240
#define BF_TIT_HEIGHT 160

#endif

