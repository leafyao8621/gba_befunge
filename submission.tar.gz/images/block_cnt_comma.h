/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_cnt_comma block_cnt_comma.png 
 * Time-stamp: Sunday 11/18/2018, 00:18:35
 * 
 * Image Information
 * -----------------
 * block_cnt_comma.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_CNT_COMMA_H
#define BLOCK_CNT_COMMA_H

extern const unsigned short block_cnt_comma[100];
#define BLOCK_CNT_COMMA_SIZE 200
#define BLOCK_CNT_COMMA_LENGTH 100
#define BLOCK_CNT_COMMA_WIDTH 10
#define BLOCK_CNT_COMMA_HEIGHT 10

#endif

