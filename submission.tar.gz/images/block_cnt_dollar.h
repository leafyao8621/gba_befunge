/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_cnt_dollar block_cnt_dollar.png 
 * Time-stamp: Sunday 11/18/2018, 00:18:08
 * 
 * Image Information
 * -----------------
 * block_cnt_dollar.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_CNT_DOLLAR_H
#define BLOCK_CNT_DOLLAR_H

extern const unsigned short block_cnt_dollar[100];
#define BLOCK_CNT_DOLLAR_SIZE 200
#define BLOCK_CNT_DOLLAR_LENGTH 100
#define BLOCK_CNT_DOLLAR_WIDTH 10
#define BLOCK_CNT_DOLLAR_HEIGHT 10

#endif

