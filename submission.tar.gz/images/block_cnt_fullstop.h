/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_cnt_fullstop block_cnt_fullstop.png 
 * Time-stamp: Sunday 11/18/2018, 00:18:21
 * 
 * Image Information
 * -----------------
 * block_cnt_fullstop.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_CNT_FULLSTOP_H
#define BLOCK_CNT_FULLSTOP_H

extern const unsigned short block_cnt_fullstop[100];
#define BLOCK_CNT_FULLSTOP_SIZE 200
#define BLOCK_CNT_FULLSTOP_LENGTH 100
#define BLOCK_CNT_FULLSTOP_WIDTH 10
#define BLOCK_CNT_FULLSTOP_HEIGHT 10

#endif

