/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_cnt_pipe block_cnt_pipe.png 
 * Time-stamp: Sunday 11/18/2018, 00:17:30
 * 
 * Image Information
 * -----------------
 * block_cnt_pipe.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_CNT_PIPE_H
#define BLOCK_CNT_PIPE_H

extern const unsigned short block_cnt_pipe[100];
#define BLOCK_CNT_PIPE_SIZE 200
#define BLOCK_CNT_PIPE_LENGTH 100
#define BLOCK_CNT_PIPE_WIDTH 10
#define BLOCK_CNT_PIPE_HEIGHT 10

#endif

