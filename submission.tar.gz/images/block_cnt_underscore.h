/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_cnt_underscore block_cnt_underscore.png 
 * Time-stamp: Sunday 11/18/2018, 00:17:13
 * 
 * Image Information
 * -----------------
 * block_cnt_underscore.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_CNT_UNDERSCORE_H
#define BLOCK_CNT_UNDERSCORE_H

extern const unsigned short block_cnt_underscore[100];
#define BLOCK_CNT_UNDERSCORE_SIZE 200
#define BLOCK_CNT_UNDERSCORE_LENGTH 100
#define BLOCK_CNT_UNDERSCORE_WIDTH 10
#define BLOCK_CNT_UNDERSCORE_HEIGHT 10

#endif

