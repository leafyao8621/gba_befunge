/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_curs_down block_curs_down.png 
 * Time-stamp: Friday 11/16/2018, 23:02:25
 * 
 * Image Information
 * -----------------
 * block_curs_down.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_CURS_DOWN_H
#define BLOCK_CURS_DOWN_H

extern const unsigned short block_curs_down[100];
#define BLOCK_CURS_DOWN_SIZE 200
#define BLOCK_CURS_DOWN_LENGTH 100
#define BLOCK_CURS_DOWN_WIDTH 10
#define BLOCK_CURS_DOWN_HEIGHT 10

#endif

