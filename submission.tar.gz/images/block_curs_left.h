/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_curs_left block_curs_left.png 
 * Time-stamp: Friday 11/16/2018, 22:57:01
 * 
 * Image Information
 * -----------------
 * block_curs_left.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_CURS_LEFT_H
#define BLOCK_CURS_LEFT_H

extern const unsigned short block_curs_left[100];
#define BLOCK_CURS_LEFT_SIZE 200
#define BLOCK_CURS_LEFT_LENGTH 100
#define BLOCK_CURS_LEFT_WIDTH 10
#define BLOCK_CURS_LEFT_HEIGHT 10

#endif

