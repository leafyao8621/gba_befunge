/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_curs_right block_curs_right.png 
 * Time-stamp: Friday 11/16/2018, 22:24:58
 * 
 * Image Information
 * -----------------
 * block_curs_right.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_CURS_RIGHT_H
#define BLOCK_CURS_RIGHT_H

extern const unsigned short block_curs_right[100];
#define BLOCK_CURS_RIGHT_SIZE 200
#define BLOCK_CURS_RIGHT_LENGTH 100
#define BLOCK_CURS_RIGHT_WIDTH 10
#define BLOCK_CURS_RIGHT_HEIGHT 10

#endif

