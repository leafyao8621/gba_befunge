/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_curs_up block_curs_up.png 
 * Time-stamp: Friday 11/16/2018, 22:06:42
 * 
 * Image Information
 * -----------------
 * block_curs_up.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_CURS_UP_H
#define BLOCK_CURS_UP_H

extern const unsigned short block_curs_up[100];
#define BLOCK_CURS_UP_SIZE 200
#define BLOCK_CURS_UP_LENGTH 100
#define BLOCK_CURS_UP_WIDTH 10
#define BLOCK_CURS_UP_HEIGHT 10

#endif

