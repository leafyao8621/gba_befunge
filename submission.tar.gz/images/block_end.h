/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_end block_end.png 
 * Time-stamp: Sunday 11/18/2018, 00:54:54
 * 
 * Image Information
 * -----------------
 * block_end.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_END_H
#define BLOCK_END_H

extern const unsigned short block_end[100];
#define BLOCK_END_SIZE 200
#define BLOCK_END_LENGTH 100
#define BLOCK_END_WIDTH 10
#define BLOCK_END_HEIGHT 10

#endif

