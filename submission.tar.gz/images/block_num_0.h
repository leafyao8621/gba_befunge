/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_num_0 block_num_0.png 
 * Time-stamp: Saturday 11/17/2018, 14:52:34
 * 
 * Image Information
 * -----------------
 * block_num_0.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_NUM_0_H
#define BLOCK_NUM_0_H

extern const unsigned short block_num_0[100];
#define BLOCK_NUM_0_SIZE 200
#define BLOCK_NUM_0_LENGTH 100
#define BLOCK_NUM_0_WIDTH 10
#define BLOCK_NUM_0_HEIGHT 10

#endif

