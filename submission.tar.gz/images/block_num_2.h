/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_num_2 block_num_2.png 
 * Time-stamp: Saturday 11/17/2018, 14:52:34
 * 
 * Image Information
 * -----------------
 * block_num_2.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_NUM_2_H
#define BLOCK_NUM_2_H

extern const unsigned short block_num_2[100];
#define BLOCK_NUM_2_SIZE 200
#define BLOCK_NUM_2_LENGTH 100
#define BLOCK_NUM_2_WIDTH 10
#define BLOCK_NUM_2_HEIGHT 10

#endif

