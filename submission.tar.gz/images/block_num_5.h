/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_num_5 block_num_5.png 
 * Time-stamp: Saturday 11/17/2018, 14:52:35
 * 
 * Image Information
 * -----------------
 * block_num_5.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_NUM_5_H
#define BLOCK_NUM_5_H

extern const unsigned short block_num_5[100];
#define BLOCK_NUM_5_SIZE 200
#define BLOCK_NUM_5_LENGTH 100
#define BLOCK_NUM_5_WIDTH 10
#define BLOCK_NUM_5_HEIGHT 10

#endif

