/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_num_7 block_num_7.png 
 * Time-stamp: Saturday 11/17/2018, 14:52:35
 * 
 * Image Information
 * -----------------
 * block_num_7.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_NUM_7_H
#define BLOCK_NUM_7_H

extern const unsigned short block_num_7[100];
#define BLOCK_NUM_7_SIZE 200
#define BLOCK_NUM_7_LENGTH 100
#define BLOCK_NUM_7_WIDTH 10
#define BLOCK_NUM_7_HEIGHT 10

#endif

