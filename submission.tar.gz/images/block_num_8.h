/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_num_8 block_num_8.png 
 * Time-stamp: Saturday 11/17/2018, 14:52:35
 * 
 * Image Information
 * -----------------
 * block_num_8.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_NUM_8_H
#define BLOCK_NUM_8_H

extern const unsigned short block_num_8[100];
#define BLOCK_NUM_8_SIZE 200
#define BLOCK_NUM_8_LENGTH 100
#define BLOCK_NUM_8_WIDTH 10
#define BLOCK_NUM_8_HEIGHT 10

#endif

