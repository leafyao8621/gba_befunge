/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_op_asterisk block_op_asterisk.png 
 * Time-stamp: Saturday 11/17/2018, 23:45:56
 * 
 * Image Information
 * -----------------
 * block_op_asterisk.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_OP_ASTERISK_H
#define BLOCK_OP_ASTERISK_H

extern const unsigned short block_op_asterisk[100];
#define BLOCK_OP_ASTERISK_SIZE 200
#define BLOCK_OP_ASTERISK_LENGTH 100
#define BLOCK_OP_ASTERISK_WIDTH 10
#define BLOCK_OP_ASTERISK_HEIGHT 10

#endif

