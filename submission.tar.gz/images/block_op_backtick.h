/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_op_backtick block_op_backtick.png 
 * Time-stamp: Saturday 11/17/2018, 23:47:09
 * 
 * Image Information
 * -----------------
 * block_op_backtick.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_OP_BACKTICK_H
#define BLOCK_OP_BACKTICK_H

extern const unsigned short block_op_backtick[100];
#define BLOCK_OP_BACKTICK_SIZE 200
#define BLOCK_OP_BACKTICK_LENGTH 100
#define BLOCK_OP_BACKTICK_WIDTH 10
#define BLOCK_OP_BACKTICK_HEIGHT 10

#endif

