/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_op_bang block_op_bang.png 
 * Time-stamp: Saturday 11/17/2018, 23:46:37
 * 
 * Image Information
 * -----------------
 * block_op_bang.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_OP_BANG_H
#define BLOCK_OP_BANG_H

extern const unsigned short block_op_bang[100];
#define BLOCK_OP_BANG_SIZE 200
#define BLOCK_OP_BANG_LENGTH 100
#define BLOCK_OP_BANG_WIDTH 10
#define BLOCK_OP_BANG_HEIGHT 10

#endif

