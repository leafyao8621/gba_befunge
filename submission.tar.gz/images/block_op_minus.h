/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_op_minus block_op_minus.png 
 * Time-stamp: Saturday 11/17/2018, 23:45:41
 * 
 * Image Information
 * -----------------
 * block_op_minus.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_OP_MINUS_H
#define BLOCK_OP_MINUS_H

extern const unsigned short block_op_minus[100];
#define BLOCK_OP_MINUS_SIZE 200
#define BLOCK_OP_MINUS_LENGTH 100
#define BLOCK_OP_MINUS_WIDTH 10
#define BLOCK_OP_MINUS_HEIGHT 10

#endif

