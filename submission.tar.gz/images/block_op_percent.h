/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_op_percent block_op_percent.png 
 * Time-stamp: Saturday 11/17/2018, 23:46:24
 * 
 * Image Information
 * -----------------
 * block_op_percent.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_OP_PERCENT_H
#define BLOCK_OP_PERCENT_H

extern const unsigned short block_op_percent[100];
#define BLOCK_OP_PERCENT_SIZE 200
#define BLOCK_OP_PERCENT_LENGTH 100
#define BLOCK_OP_PERCENT_WIDTH 10
#define BLOCK_OP_PERCENT_HEIGHT 10

#endif

