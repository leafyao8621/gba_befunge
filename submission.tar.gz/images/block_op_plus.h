/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_op_plus block_op_plus.png 
 * Time-stamp: Saturday 11/17/2018, 23:45:26
 * 
 * Image Information
 * -----------------
 * block_op_plus.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_OP_PLUS_H
#define BLOCK_OP_PLUS_H

extern const unsigned short block_op_plus[100];
#define BLOCK_OP_PLUS_SIZE 200
#define BLOCK_OP_PLUS_LENGTH 100
#define BLOCK_OP_PLUS_WIDTH 10
#define BLOCK_OP_PLUS_HEIGHT 10

#endif

