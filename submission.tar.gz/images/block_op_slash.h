/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 block_op_slash block_op_slash.png 
 * Time-stamp: Saturday 11/17/2018, 23:46:09
 * 
 * Image Information
 * -----------------
 * block_op_slash.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLOCK_OP_SLASH_H
#define BLOCK_OP_SLASH_H

extern const unsigned short block_op_slash[100];
#define BLOCK_OP_SLASH_SIZE 200
#define BLOCK_OP_SLASH_LENGTH 100
#define BLOCK_OP_SLASH_WIDTH 10
#define BLOCK_OP_SLASH_HEIGHT 10

#endif

