/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 curs curs.png 
 * Time-stamp: Friday 11/16/2018, 19:00:33
 * 
 * Image Information
 * -----------------
 * curs.png 5@5
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CURS_H
#define CURS_H

extern const unsigned short curs[25];
#define CURS_SIZE 50
#define CURS_LENGTH 25
#define CURS_WIDTH 5
#define CURS_HEIGHT 5

#endif

