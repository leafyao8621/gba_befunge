/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 curs_exec_left curs_exec_left.png 
 * Time-stamp: Sunday 11/18/2018, 20:22:36
 * 
 * Image Information
 * -----------------
 * curs_exec_left.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CURS_EXEC_LEFT_H
#define CURS_EXEC_LEFT_H

extern const unsigned short curs_exec_left[100];
#define CURS_EXEC_LEFT_SIZE 200
#define CURS_EXEC_LEFT_LENGTH 100
#define CURS_EXEC_LEFT_WIDTH 10
#define CURS_EXEC_LEFT_HEIGHT 10

#endif

