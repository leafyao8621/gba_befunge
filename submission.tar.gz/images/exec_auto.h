/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 exec_auto exec_auto.png 
 * Time-stamp: Tuesday 11/20/2018, 10:18:22
 * 
 * Image Information
 * -----------------
 * exec_auto.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef EXEC_AUTO_H
#define EXEC_AUTO_H

extern const unsigned short exec_auto[100];
#define EXEC_AUTO_SIZE 200
#define EXEC_AUTO_LENGTH 100
#define EXEC_AUTO_WIDTH 10
#define EXEC_AUTO_HEIGHT 10

#endif

