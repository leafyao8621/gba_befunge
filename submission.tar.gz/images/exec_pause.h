/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 exec_pause exec_pause.png 
 * Time-stamp: Tuesday 11/20/2018, 10:18:10
 * 
 * Image Information
 * -----------------
 * exec_pause.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef EXEC_PAUSE_H
#define EXEC_PAUSE_H

extern const unsigned short exec_pause[100];
#define EXEC_PAUSE_SIZE 200
#define EXEC_PAUSE_LENGTH 100
#define EXEC_PAUSE_WIDTH 10
#define EXEC_PAUSE_HEIGHT 10

#endif

